
NAME='emperor_zeromq'
CFLAGS = []
LDFLAGS = []
LIBS = ['-lzmq']

GCC_LIST = ['emperor_zeromq']
