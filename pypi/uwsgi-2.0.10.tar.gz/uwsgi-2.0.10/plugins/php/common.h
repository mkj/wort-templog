#include "php.h"
#include "SAPI.h"
#include "php_main.h"
#include "php_variables.h"

#include "ext/standard/php_smart_str.h"
#include "ext/standard/info.h"

#include "ext/session/php_session.h"

#include <uwsgi.h>

