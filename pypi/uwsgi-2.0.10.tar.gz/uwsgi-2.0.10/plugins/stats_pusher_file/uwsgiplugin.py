NAME='stats_pusher_file'

CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['plugin']
